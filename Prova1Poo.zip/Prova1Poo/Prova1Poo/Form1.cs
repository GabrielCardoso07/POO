﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prova1Poo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            pictureBox1.Image = Properties.Resources.branco;
        }

        private void radioButtonOnibus_CheckedChanged(object sender, EventArgs e)
        {
            pictureBox1.Image = Properties.Resources.onibus;
        }

        private void radioButtonCaminhao_CheckedChanged(object sender, EventArgs e)
        {
            pictureBox1.Image= Properties.Resources.caminhao;
        }

        private void buttonLimpar_Click(object sender, EventArgs e)
        {
            maskedTextBoxPlaca.Clear();
            textBoxAno.Clear();
            textBoxAssentos.Clear();
        }

        private void buttonCadastrar_Click(object sender, EventArgs e)
        {
            if(radioButtonOnibus.Checked == true)
            {
                listView1 = Convert.ToDouble(maskedTextBoxPlaca.Text, textBoxAno 
            }
        }
    }
}
