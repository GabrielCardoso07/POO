﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prova1Poo
{
    internal class Caminhao : Veiculo
    {
        //atributos
        private int eixos;


        //getters & setters
        public int Eixos { get => eixos; set => eixos = value; }

        //metodos
        public Caminhao(string _placa, int _ano, int _eixos) : base(_placa, _ano)
        {
            eixos = _eixos;
        }

        public override double alugar()
        {
            return (300 * Eixos) - (2023 - Ano) * 50;   
        }

    }//fim da classe Caminhao
}
