﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prova1Poo
{
    internal class Veiculo
    {
        //atributos
        protected string placa;
        protected int ano;

        //metodos
        public Veiculo()
        {

        }

        public Veiculo(string _placa, int _ano)
        {
            placa = _placa;
            ano = _ano;
        }

        public virtual double alugar()
        {
            return 0.0;
        }

        //getters & setters
        public string Placa { get => placa; set => placa = value; }
        public int Ano { get => ano; set => ano = value; }
    } //fim da classe Veiculo
}
