﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prova1Poo
{
    internal class Onibus : Veiculo
    {
        //atributos
        private int assentos;

        //getters & setters
        public int Assentos { get => assentos; set => assentos = value; }

        //metodos
        public Onibus(string _placa, int _ano, int _assentos) : base(_placa, _ano)
        {
            assentos = _assentos;
        }

        public override double alugar()
        {
            return (30 * Assentos) - (2023 - Ano) * 70;
        }

    } // fim da classe Onibus
}
