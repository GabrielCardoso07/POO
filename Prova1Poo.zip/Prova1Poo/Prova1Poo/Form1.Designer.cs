﻿namespace Prova1Poo
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.ListViewItem listViewItem1 = new System.Windows.Forms.ListViewItem("Placa");
            System.Windows.Forms.ListViewItem listViewItem2 = new System.Windows.Forms.ListViewItem("Ano");
            System.Windows.Forms.ListViewItem listViewItem3 = new System.Windows.Forms.ListViewItem("Assentos");
            System.Windows.Forms.ListViewItem listViewItem4 = new System.Windows.Forms.ListViewItem("Eixos");
            System.Windows.Forms.ListViewItem listViewItem5 = new System.Windows.Forms.ListViewItem("Diária");
            this.radioButtonOnibus = new System.Windows.Forms.RadioButton();
            this.radioButtonCaminhao = new System.Windows.Forms.RadioButton();
            this.labelPlaca = new System.Windows.Forms.Label();
            this.labelAno = new System.Windows.Forms.Label();
            this.labelQtdAssentos = new System.Windows.Forms.Label();
            this.buttonCadastrar = new System.Windows.Forms.Button();
            this.buttonLimpar = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.maskedTextBoxPlaca = new System.Windows.Forms.MaskedTextBox();
            this.listView1 = new System.Windows.Forms.ListView();
            this.textBoxAno = new System.Windows.Forms.TextBox();
            this.textBoxAssentos = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // radioButtonOnibus
            // 
            this.radioButtonOnibus.AutoSize = true;
            this.radioButtonOnibus.Location = new System.Drawing.Point(23, 12);
            this.radioButtonOnibus.Name = "radioButtonOnibus";
            this.radioButtonOnibus.Size = new System.Drawing.Size(58, 17);
            this.radioButtonOnibus.TabIndex = 0;
            this.radioButtonOnibus.Text = "Ônibus";
            this.radioButtonOnibus.UseVisualStyleBackColor = true;
            this.radioButtonOnibus.CheckedChanged += new System.EventHandler(this.radioButtonOnibus_CheckedChanged);
            // 
            // radioButtonCaminhao
            // 
            this.radioButtonCaminhao.AutoSize = true;
            this.radioButtonCaminhao.Location = new System.Drawing.Point(162, 12);
            this.radioButtonCaminhao.Name = "radioButtonCaminhao";
            this.radioButtonCaminhao.Size = new System.Drawing.Size(72, 17);
            this.radioButtonCaminhao.TabIndex = 1;
            this.radioButtonCaminhao.Text = "Caminhão";
            this.radioButtonCaminhao.UseVisualStyleBackColor = true;
            this.radioButtonCaminhao.CheckedChanged += new System.EventHandler(this.radioButtonCaminhao_CheckedChanged);
            // 
            // labelPlaca
            // 
            this.labelPlaca.AutoSize = true;
            this.labelPlaca.Location = new System.Drawing.Point(82, 63);
            this.labelPlaca.Name = "labelPlaca";
            this.labelPlaca.Size = new System.Drawing.Size(34, 13);
            this.labelPlaca.TabIndex = 2;
            this.labelPlaca.Text = "Placa";
            // 
            // labelAno
            // 
            this.labelAno.AutoSize = true;
            this.labelAno.Location = new System.Drawing.Point(82, 114);
            this.labelAno.Name = "labelAno";
            this.labelAno.Size = new System.Drawing.Size(26, 13);
            this.labelAno.TabIndex = 3;
            this.labelAno.Text = "Ano";
            // 
            // labelQtdAssentos
            // 
            this.labelQtdAssentos.AutoSize = true;
            this.labelQtdAssentos.Location = new System.Drawing.Point(82, 162);
            this.labelQtdAssentos.Name = "labelQtdAssentos";
            this.labelQtdAssentos.Size = new System.Drawing.Size(70, 13);
            this.labelQtdAssentos.TabIndex = 4;
            this.labelQtdAssentos.Text = "Qtd Assentos";
            // 
            // buttonCadastrar
            // 
            this.buttonCadastrar.Location = new System.Drawing.Point(76, 231);
            this.buttonCadastrar.Name = "buttonCadastrar";
            this.buttonCadastrar.Size = new System.Drawing.Size(90, 32);
            this.buttonCadastrar.TabIndex = 8;
            this.buttonCadastrar.TabStop = false;
            this.buttonCadastrar.Text = "Cadastrar";
            this.buttonCadastrar.UseVisualStyleBackColor = true;
            this.buttonCadastrar.Click += new System.EventHandler(this.buttonCadastrar_Click);
            // 
            // buttonLimpar
            // 
            this.buttonLimpar.Location = new System.Drawing.Point(205, 231);
            this.buttonLimpar.Name = "buttonLimpar";
            this.buttonLimpar.Size = new System.Drawing.Size(97, 32);
            this.buttonLimpar.TabIndex = 9;
            this.buttonLimpar.TabStop = false;
            this.buttonLimpar.Text = "Limpar";
            this.buttonLimpar.UseVisualStyleBackColor = true;
            this.buttonLimpar.Click += new System.EventHandler(this.buttonLimpar_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pictureBox1.Image = global::Prova1Poo.Properties.Resources.onibus;
            this.pictureBox1.Location = new System.Drawing.Point(453, 39);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(256, 173);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 10;
            this.pictureBox1.TabStop = false;
            // 
            // maskedTextBoxPlaca
            // 
            this.maskedTextBoxPlaca.Location = new System.Drawing.Point(162, 63);
            this.maskedTextBoxPlaca.Mask = "LLL-0000";
            this.maskedTextBoxPlaca.Name = "maskedTextBoxPlaca";
            this.maskedTextBoxPlaca.Size = new System.Drawing.Size(100, 20);
            this.maskedTextBoxPlaca.TabIndex = 12;
            // 
            // listView1
            // 
            this.listView1.HideSelection = false;
            this.listView1.Items.AddRange(new System.Windows.Forms.ListViewItem[] {
            listViewItem1,
            listViewItem2,
            listViewItem3,
            listViewItem4,
            listViewItem5});
            this.listView1.Location = new System.Drawing.Point(23, 303);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(686, 97);
            this.listView1.TabIndex = 15;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.SmallIcon;
            // 
            // textBoxAno
            // 
            this.textBoxAno.Location = new System.Drawing.Point(162, 114);
            this.textBoxAno.Name = "textBoxAno";
            this.textBoxAno.Size = new System.Drawing.Size(100, 20);
            this.textBoxAno.TabIndex = 16;
            // 
            // textBoxAssentos
            // 
            this.textBoxAssentos.Location = new System.Drawing.Point(162, 162);
            this.textBoxAssentos.Name = "textBoxAssentos";
            this.textBoxAssentos.Size = new System.Drawing.Size(100, 20);
            this.textBoxAssentos.TabIndex = 17;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.textBoxAssentos);
            this.Controls.Add(this.textBoxAno);
            this.Controls.Add(this.listView1);
            this.Controls.Add(this.maskedTextBoxPlaca);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.buttonLimpar);
            this.Controls.Add(this.buttonCadastrar);
            this.Controls.Add(this.labelQtdAssentos);
            this.Controls.Add(this.labelAno);
            this.Controls.Add(this.labelPlaca);
            this.Controls.Add(this.radioButtonCaminhao);
            this.Controls.Add(this.radioButtonOnibus);
            this.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RadioButton radioButtonOnibus;
        private System.Windows.Forms.RadioButton radioButtonCaminhao;
        private System.Windows.Forms.Label labelPlaca;
        private System.Windows.Forms.Label labelAno;
        private System.Windows.Forms.Label labelQtdAssentos;
        private System.Windows.Forms.Button buttonCadastrar;
        private System.Windows.Forms.Button buttonLimpar;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.MaskedTextBox maskedTextBoxPlaca;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.TextBox textBoxAno;
        private System.Windows.Forms.TextBox textBoxAssentos;
    }
}

